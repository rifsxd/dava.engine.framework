#ifndef __XML_CONFIG_MAC_H__
#define __XML_CONFIG_MAC_H__

/* config.h.in.  Generated from configure.in by autoheader.  */
#include "config.h"

#endif //#ifdef __XML_CONFIG_MAC_H__
